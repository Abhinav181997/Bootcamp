package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Customer;

@Service
public interface IManageCustomerService {

	public List<Customer> listAllCustomers();

	public Customer createCustomer(Customer customer);
	
	public Customer getCustomer(int customerId);
}
