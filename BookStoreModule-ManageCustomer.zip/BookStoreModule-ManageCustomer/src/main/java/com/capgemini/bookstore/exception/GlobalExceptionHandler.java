package com.capgemini.bookstore.exception;

public class GlobalExceptionHandler {

}
