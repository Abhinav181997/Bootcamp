package com.capgemini.bookstore.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.beans.Customer;

@Repository
public interface IManageCustomerRepo {

	public Customer saveCustomer(Customer customer);

	public Customer findCustomerById(int customerId);
	
	public List<Customer> findAllCustomers();

}
