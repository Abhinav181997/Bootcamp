package com.capgemini.bookstore.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.service.IManageCustomerService;

@RestController
@Validated 
public class ManageCustomerController {

	@Autowired
	IManageCustomerService managecustomerservice;
	
	@RequestMapping(method = RequestMethod.PUT,value = "/createCustomer")
	public Customer createCustomer(@Valid @RequestBody Customer customer) {
		return managecustomerservice.createCustomer(customer);
		
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/getCustomer/{customerId}")
	public Customer getCustomer(@PathVariable int customerId) {
		return managecustomerservice.getCustomer(customerId);
		
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "/listAllCustomers")
	public List<Customer> listAllCustomers() {
		return managecustomerservice.listAllCustomers();
		
	}
}
