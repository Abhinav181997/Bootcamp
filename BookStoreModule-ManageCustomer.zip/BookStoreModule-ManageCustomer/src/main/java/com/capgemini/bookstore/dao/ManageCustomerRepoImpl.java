package com.capgemini.bookstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.capgemini.bookstore.beans.Customer;

@Repository
@Transactional
public class ManageCustomerRepoImpl implements IManageCustomerRepo {

	@PersistenceContext
	EntityManager entitymanager;

	@Override 
	public Customer saveCustomer(Customer customer) {
		entitymanager.persist(customer);
		return customer;
	}

	@Override
	public List<Customer> findAllCustomers() {

		return entitymanager.createQuery("select c from Customer c", Customer.class).getResultList();
	}

	@Override
	public Customer findCustomerById(int customerId) {
		return entitymanager.find(Customer.class, customerId);
	}

}
